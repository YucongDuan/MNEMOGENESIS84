from __future__ import annotations
import json
import tempfile
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from mnemogenesis84.core import (
    accept_memory,
    audit_workspace,
    compare_reconstructions,
    consolidate,
    export_capsule,
    forget,
    ingest_event,
    init_workspace,
    life_boundary,
    proactive_pulse,
    prospect,
    recall,
    save_reconstruction,
    selftest,
    summary,
    verify_ledger,
)

results = []

def check(name, condition, detail=None):
    results.append((name, bool(condition), detail))

check("summary", summary()["memory_life_gates"] == 10)
check("selftest", selftest()["passed"], selftest())
with tempfile.TemporaryDirectory() as td:
    root = Path(td) / "living"
    init_workspace(root, "T", "A")
    for p in sorted((ROOT / "examples" / "events").glob("*.json")):
        ingest_event(root, json.loads(p.read_text(encoding="utf-8")))
    c1 = json.loads((ROOT / "examples" / "contexts" / "source_recovery.json").read_text(encoding="utf-8"))
    m1 = recall(root, **c1)
    accept_memory(root, m1)
    c2 = json.loads((ROOT / "examples" / "contexts" / "future_collaboration.json").read_text(encoding="utf-8"))
    m2 = recall(root, **c2)
    save_reconstruction(root, m2)
    check("reconstruction_differs", compare_reconstructions(m1, m2)["non_fidelity_demonstrated"])
    consolidate(root)
    prospect(root)
    proactive_pulse(root)
    forget(root, decay=0.02)
    check("living_memory_candidate", life_boundary(root)["state"] == "LIVING_MEMORY_CANDIDATE", life_boundary(root))
    check("ledger_valid", verify_ledger(root)["valid"])
    check("workspace_valid", audit_workspace(root)["valid"], audit_workspace(root))
    cap = export_capsule(root, Path(td) / "cap.zip")
    check("capsule", Path(cap["zip"]).exists())

    storage = Path(td) / "storage"
    init_workspace(storage, "S", "A")
    ingest_event(storage, {"event_id":"E","content":"An exact record is stored.","source_type":"document"})
    check("storage_only", life_boundary(storage)["state"] == "ARCHIVE_OR_STORAGE_ONLY")

for name, ok, detail in results:
    print(("PASS" if ok else "FAIL"), name, "" if ok else detail)
print(f"{sum(1 for _, ok, _ in results if ok)} passed, {sum(1 for _, ok, _ in results if not ok)} failed")
raise SystemExit(0 if all(ok for _, ok, _ in results) else 1)
