# 当前大模型升级指南 / Upgrade Guide for Current LLMs

## 最小接入

1. 把原始会话、文档或工具输出写入独立证据档案。
2. 只从档案生成带来源指针的痕迹。
3. 每次回忆必须声明 cue、Purpose、模型版本和当前状态。
4. 模型输出中的每个记忆主张标为 direct、synthesis、hypothesis 或 prospection。
5. 只有经过本地审计并被接受的回忆才能进入再巩固。
6. 自身模型和未来目标由接受的记忆版本更新。
7. 记忆胶囊必须能迁移到第二模型。

## 禁止偷换

- Context window ≠ memory
- Vector retrieval ≠ recall
- Summary ≠ autobiographical continuity
- Fine-tuning ≠ provenance-aware reconsolidation
- Role prompt ≠ self
- Stored user profile ≠ living memory
- Fluent self-report ≠ phenomenal consciousness
