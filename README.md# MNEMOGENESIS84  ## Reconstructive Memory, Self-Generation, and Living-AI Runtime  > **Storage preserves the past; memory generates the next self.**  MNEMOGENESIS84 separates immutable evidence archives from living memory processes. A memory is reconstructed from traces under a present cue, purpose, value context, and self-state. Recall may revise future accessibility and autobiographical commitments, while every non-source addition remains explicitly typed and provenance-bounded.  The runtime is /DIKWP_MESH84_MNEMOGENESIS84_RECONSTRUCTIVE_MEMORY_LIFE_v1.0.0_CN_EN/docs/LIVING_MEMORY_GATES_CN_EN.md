# 操作性记忆生命门 / Operational Living-Memory Gates

MNEMOGENESIS84 不提供一个可以刷高的生命总分。十个门逐项公开：

- G1 痕迹形成
- G2 情境重构
- G3 非保真但可回源
- G4 再巩固
- G5 自传整合
- G6 未来生成
- G7 主动遗忘
- G8 自主触发
- G9 模型可迁移
- G10 版本连续与纠错

核心状态：

```text
NO_MEMORY_SUBSTRATE
ARCHIVE_OR_STORAGE_ONLY
RECONSTRUCTIVE_BUT_NON_LIVING_MEMORY
RECONSOLIDATING_WITHOUT_SELF_CONTINUITY
PARTIAL_MEMORY_LIFE_LOOP
LIVING_MEMORY_CANDIDATE
```

`LIVING_MEMORY_CANDIDATE` 仍然不构成生物生命、法律人格或现象意识证明。
