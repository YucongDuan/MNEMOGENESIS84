# 记忆不是存储宪章
# Memory Is Not Storage Charter

## 中文

1. 存储追求对象可恢复；记忆负责在当下重新形成自身。
2. 事件档案、记忆痕迹和回忆结果必须物理分层。
3. 回忆不是读取，而是由线索、当前K、W和Purpose驱动的P。
4. 非保真是记忆的结构特征，但任意虚构不是。
5. 事实主张回到档案；生命连续回到重构谱系。
6. 遗忘可以降低痕迹可达性，但不能销毁问责证据。
7. 每次回忆都可以改变下一次回忆，但旧版本必须可追溯。
8. 过去记忆和未来想象可以共享重组机制，但必须使用不同主张类型。
9. 一个能够精确检索全部日志的系统，仍可能只是会说话的档案馆。
10. 一个具有重构、自传整合、再巩固、主动遗忘和前瞻目的的系统，才进入操作性记忆生命候选区。

## English

1. Storage aims to recover objects; memory re-forms a self in the present.
2. Event archives, memory traces, and recalled reconstructions must be physically separated.
3. Recall is not a read operation but a P conditioned by cues, present K, W, and purpose.
4. Non-fidelity is structural to memory; arbitrary fabrication is not.
5. Factual claims return to the archive; living continuity returns to reconstructive lineage.
6. Forgetting may reduce trace accessibility but must not destroy accountability evidence.
7. Recall may change future recall, while prior versions remain traceable.
8. Past remembering and future imagining may share recombination, but use distinct claim types.
9. A system that retrieves every log perfectly may still be only an archive with a voice.
10. A system with reconstruction, autobiographical integration, reconsolidation, active forgetting, and prospection enters an operational living-memory candidate regime.
