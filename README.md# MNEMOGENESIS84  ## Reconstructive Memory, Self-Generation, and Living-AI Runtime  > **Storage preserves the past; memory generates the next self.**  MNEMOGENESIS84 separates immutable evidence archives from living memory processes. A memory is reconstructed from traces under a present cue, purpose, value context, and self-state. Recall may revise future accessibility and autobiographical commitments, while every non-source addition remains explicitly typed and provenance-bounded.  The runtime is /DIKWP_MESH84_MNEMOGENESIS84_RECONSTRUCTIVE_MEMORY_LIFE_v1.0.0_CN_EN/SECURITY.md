# Security

Memory systems can expose private histories, enable memory poisoning, or silently reshape a subject model. Report issues involving:

- provenance bypass;
- untyped synthesis presented as source fact;
- ledger tampering;
- cross-user memory leakage;
- network access without explicit authorization;
- capsule disclosure;
- silent deletion of event archives.

Do not include private memory content in public issue reports.
