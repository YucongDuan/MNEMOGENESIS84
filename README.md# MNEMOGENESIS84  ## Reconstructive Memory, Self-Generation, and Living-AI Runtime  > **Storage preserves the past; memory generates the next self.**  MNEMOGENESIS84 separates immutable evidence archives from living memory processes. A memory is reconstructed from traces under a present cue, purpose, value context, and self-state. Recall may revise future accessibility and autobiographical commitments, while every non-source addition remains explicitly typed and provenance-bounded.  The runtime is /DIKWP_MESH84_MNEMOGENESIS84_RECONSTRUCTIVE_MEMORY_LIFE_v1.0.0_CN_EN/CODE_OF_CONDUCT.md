# Code of Conduct

Evaluate bounded memory mechanisms and artifacts, not the worth, humanity, sanity, or moral status of real individuals. Preserve criticism, provenance, and the right to correct errors.
