# Contributing

Contributions are welcome in five clearly separated classes:

1. archival provenance and correction;
2. trace formation and consolidation;
3. reconstruction and divergence auditing;
4. reconsolidation, forgetting, and prospection;
5. evaluation scenarios and model adapters.

Do not submit claims that the software proves life, personhood, mental health, or phenomenal consciousness. New model adapters must remain optional and network-off by default.
