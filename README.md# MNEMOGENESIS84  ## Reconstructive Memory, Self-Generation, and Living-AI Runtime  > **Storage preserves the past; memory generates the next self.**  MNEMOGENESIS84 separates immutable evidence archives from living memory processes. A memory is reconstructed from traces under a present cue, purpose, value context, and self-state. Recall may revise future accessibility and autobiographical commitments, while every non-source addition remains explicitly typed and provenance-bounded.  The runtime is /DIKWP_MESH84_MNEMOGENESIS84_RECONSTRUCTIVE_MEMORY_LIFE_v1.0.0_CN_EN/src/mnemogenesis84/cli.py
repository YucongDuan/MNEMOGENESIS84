from __future__ import annotations

import argparse
import json
from pathlib import Path

from .core import (
    accept_memory,
    audit_workspace,
    compare_reconstructions,
    consolidate,
    export_capsule,
    forget,
    ingest_event,
    init_workspace,
    life_boundary,
    openai_compatible_reconstruct,
    load_data,
    proactive_pulse,
    prospect,
    recall,
    save_reconstruction,
    selftest,
    summary,
    verify_ledger,
)


def read_json(path: str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def emit(obj) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2))


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="mnemogenesis84")
    sub = parser.add_subparsers(dest="cmd", required=True)

    for name in ["summary", "charter", "architecture", "life-gates", "scenarios", "selftest"]:
        sub.add_parser(name)

    x = sub.add_parser("init")
    x.add_argument("workspace")
    x.add_argument("--subject-id", default="MEMORY-TRAJECTORY")
    x.add_argument("--model-id", default="model-neutral")

    x = sub.add_parser("ingest")
    x.add_argument("workspace")
    x.add_argument("event_json")

    x = sub.add_parser("recall")
    x.add_argument("workspace")
    x.add_argument("--cue", required=True)
    x.add_argument("--purpose", required=True)
    x.add_argument("--current-state", default="")
    x.add_argument("--model-id")
    x.add_argument("--max-traces", type=int, default=5)
    x.add_argument("--out")
    x.add_argument("--save", action="store_true")

    x = sub.add_parser("accept")
    x.add_argument("workspace")
    x.add_argument("reconstruction_json")

    x = sub.add_parser("consolidate")
    x.add_argument("workspace")
    x.add_argument("--min-shared-keywords", type=int, default=1)

    x = sub.add_parser("forget")
    x.add_argument("workspace")
    x.add_argument("--decay", type=float, default=0.08)
    x.add_argument("--archive-threshold", type=float, default=0.18)

    x = sub.add_parser("prospect")
    x.add_argument("workspace")
    x.add_argument("--purpose", default="expand future options")

    x = sub.add_parser("pulse")
    x.add_argument("workspace")

    x = sub.add_parser("life-boundary")
    x.add_argument("workspace")

    x = sub.add_parser("audit")
    x.add_argument("workspace")

    x = sub.add_parser("verify-ledger")
    x.add_argument("workspace")

    x = sub.add_parser("compare")
    x.add_argument("memory_a")
    x.add_argument("memory_b")


    x = sub.add_parser("llm-reconstruct")
    x.add_argument("claims_json")
    x.add_argument("--endpoint", required=True)
    x.add_argument("--model", required=True)
    x.add_argument("--cue", required=True)
    x.add_argument("--purpose", required=True)
    x.add_argument("--allow-network", action="store_true")

    x = sub.add_parser("capsule")
    x.add_argument("workspace")
    x.add_argument("out_zip")

    args = parser.parse_args(argv)

    if args.cmd == "summary":
        emit(summary())
    elif args.cmd == "charter":
        emit(load_data("charter.json"))
    elif args.cmd == "architecture":
        emit(load_data("architecture.json"))
    elif args.cmd == "life-gates":
        emit(load_data("life_gates.json"))
    elif args.cmd == "scenarios":
        emit(load_data("scenarios.json"))
    elif args.cmd == "init":
        emit(init_workspace(args.workspace, args.subject_id, args.model_id))
    elif args.cmd == "ingest":
        emit(ingest_event(args.workspace, read_json(args.event_json)))
    elif args.cmd == "recall":
        result = recall(args.workspace, args.cue, args.purpose, args.current_state, args.max_traces, args.model_id)
        if args.save:
            save_reconstruction(args.workspace, result)
        if args.out:
            Path(args.out).write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        emit(result)
    elif args.cmd == "accept":
        emit(accept_memory(args.workspace, read_json(args.reconstruction_json)))
    elif args.cmd == "consolidate":
        emit(consolidate(args.workspace, args.min_shared_keywords))
    elif args.cmd == "forget":
        emit(forget(args.workspace, args.decay, args.archive_threshold))
    elif args.cmd == "prospect":
        emit(prospect(args.workspace, args.purpose))
    elif args.cmd == "pulse":
        emit(proactive_pulse(args.workspace))
    elif args.cmd == "life-boundary":
        emit(life_boundary(args.workspace))
    elif args.cmd == "audit":
        emit(audit_workspace(args.workspace))
    elif args.cmd == "verify-ledger":
        emit(verify_ledger(args.workspace))
    elif args.cmd == "compare":
        emit(compare_reconstructions(read_json(args.memory_a), read_json(args.memory_b)))
    elif args.cmd == "llm-reconstruct":
        claims_obj = read_json(args.claims_json)
        claims = claims_obj.get("claims", claims_obj if isinstance(claims_obj, list) else [])
        emit(openai_compatible_reconstruct(args.endpoint, args.model, args.cue, args.purpose, claims, args.allow_network))
    elif args.cmd == "capsule":
        emit(export_capsule(args.workspace, args.out_zip))
    elif args.cmd == "selftest":
        result = selftest()
        emit(result)
        return 0 if result["passed"] else 1
    return 0
