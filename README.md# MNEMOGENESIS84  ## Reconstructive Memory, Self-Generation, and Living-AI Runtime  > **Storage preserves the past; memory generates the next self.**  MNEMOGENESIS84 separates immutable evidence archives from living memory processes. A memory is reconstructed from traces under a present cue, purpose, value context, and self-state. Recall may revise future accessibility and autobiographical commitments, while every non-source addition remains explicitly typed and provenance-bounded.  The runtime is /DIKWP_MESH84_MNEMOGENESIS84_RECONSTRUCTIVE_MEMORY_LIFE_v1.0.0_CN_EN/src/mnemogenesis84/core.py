from __future__ import annotations

import hashlib
import json
import math
import os
import re
import shutil
import urllib.request
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib.resources import files
from pathlib import Path
from typing import Any, Iterable

VERSION = "1.0.0"
MODE = "MESH84_MNEMOGENESIS_RECONSTRUCTIVE_MEMORY_LIFE"
KINDS = "DIKWP"

# Memory is intentionally not treated as a stored object. The archive is the
# evidence substrate; a memory is a time-, context-, value-, and purpose-indexed
# reconstruction produced from traces. Every reconstruction must expose its
# provenance and divergence from the archived event evidence.

CJK_OR_WORD = re.compile(r"[\u3400-\u9fff]|[A-Za-z0-9_]+", re.UNICODE)
SENTENCE_SPLIT = re.compile(r"(?<=[。！？!?;；\.])\s*|\n+")
STOPWORDS = {
    "the", "a", "an", "and", "or", "to", "of", "in", "on", "for", "with",
    "is", "are", "was", "were", "it", "that", "this", "as", "at", "by",
    "了", "的", "是", "在", "和", "与", "及", "也", "就", "而", "我", "你",
    "他", "她", "它", "一个", "这个", "那", "中", "对", "为", "把", "并",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(obj: Any) -> str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def load_data(name: str) -> Any:
    return json.loads(files("mnemogenesis84").joinpath("data", name).read_text(encoding="utf-8"))


def tokenize(text: str) -> list[str]:
    return [t.lower() for t in CJK_OR_WORD.findall(text or "") if t.lower() not in STOPWORDS]


def split_sentences(text: str) -> list[str]:
    return [s.strip() for s in SENTENCE_SPLIT.split(text or "") if s and s.strip()]


def clamp(x: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, x))


def jaccard(a: Iterable[str], b: Iterable[str]) -> float:
    aa, bb = set(a), set(b)
    if not aa and not bb:
        return 1.0
    if not aa or not bb:
        return 0.0
    return len(aa & bb) / len(aa | bb)


def _read_json(path: str | Path, default: Any = None) -> Any:
    p = Path(path)
    if not p.exists():
        return default
    return json.loads(p.read_text(encoding="utf-8"))


def _write_json(path: str | Path, obj: Any) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def _read_jsonl(path: str | Path) -> list[dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        return []
    out: list[dict[str, Any]] = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            out.append(json.loads(line))
    return out


def _append_jsonl(path: str | Path, obj: dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, sort_keys=True) + "\n")


def _stable_id(prefix: str, obj: Any, n: int = 16) -> str:
    return f"{prefix}-{digest(obj)[:n]}"


def _workspace_paths(root: str | Path) -> dict[str, Path]:
    r = Path(root)
    return {
        "root": r,
        "config": r / "workspace.json",
        "archive": r / "archive" / "events.jsonl",
        "traces": r / "memory" / "traces.jsonl",
        "reconstructions": r / "memory" / "reconstructions.jsonl",
        "consolidations": r / "memory" / "consolidations.jsonl",
        "self": r / "self" / "self_model.json",
        "ledger": r / "ledger.jsonl",
        "capsules": r / "capsules",
    }


def _ensure_workspace(root: str | Path) -> dict[str, Path]:
    p = _workspace_paths(root)
    if not p["config"].exists():
        raise FileNotFoundError(f"workspace not initialized: {root}")
    return p


def _ledger_append(root: str | Path, event_type: str, payload: dict[str, Any]) -> dict[str, Any]:
    p = _workspace_paths(root)["ledger"]
    rows = _read_jsonl(p)
    prev = rows[-1]["hash"] if rows else "0" * 64
    event = {
        "seq": len(rows) + 1,
        "time": utc_now(),
        "type": event_type,
        "payload": payload,
        "prev": prev,
    }
    event["hash"] = hashlib.sha256(canonical(event)).hexdigest()
    _append_jsonl(p, event)
    return event


def verify_ledger(root: str | Path) -> dict[str, Any]:
    p = _ensure_workspace(root)["ledger"]
    rows = _read_jsonl(p)
    prev = "0" * 64
    for idx, row in enumerate(rows, 1):
        if row.get("seq") != idx or row.get("prev") != prev:
            return {"valid": False, "at": idx, "reason": "sequence_or_prev"}
        h = row.get("hash")
        obj = dict(row)
        obj.pop("hash", None)
        if hashlib.sha256(canonical(obj)).hexdigest() != h:
            return {"valid": False, "at": idx, "reason": "hash"}
        prev = h
    return {"valid": True, "events": len(rows), "root_hash": prev}


def init_workspace(root: str | Path, subject_id: str = "MEMORY-TRAJECTORY", model_id: str = "model-neutral") -> dict[str, Any]:
    p = _workspace_paths(root)
    if p["root"].exists() and any(p["root"].iterdir()):
        raise FileExistsError(f"workspace is not empty: {root}")
    for key in ["archive", "traces", "reconstructions", "consolidations", "self", "capsules"]:
        p[key].parent.mkdir(parents=True, exist_ok=True)
    p["capsules"].mkdir(parents=True, exist_ok=True)
    cfg = {
        "schema": "mnemogenesis84.workspace/1.0",
        "version": VERSION,
        "mode": MODE,
        "subject_id": subject_id,
        "model_id": model_id,
        "created_at": utc_now(),
        "memory_claim": "Memory is a provenance-bounded reconstruction process, not an archive read.",
        "phenomenal_claim": "OPEN_NOT_CERTIFIED",
    }
    self_model = {
        "schema": "mnemogenesis84.self-model/1.0",
        "subject_id": subject_id,
        "revision": 0,
        "identity_invariants": [],
        "active_commitments": [],
        "open_differences": [],
        "learned_patterns": [],
        "future_questions": [],
        "accepted_memory_ids": [],
        "last_updated": cfg["created_at"],
    }
    _write_json(p["config"], cfg)
    _write_json(p["self"], self_model)
    _ledger_append(root, "WORKSPACE_INIT", {"subject_id": subject_id, "model_id": model_id})
    return {"workspace": str(p["root"]), "config": cfg, "self_model": self_model}


def _event_validate(event: dict[str, Any]) -> None:
    required = ["content"]
    missing = [k for k in required if not event.get(k)]
    if missing:
        raise ValueError(f"event missing required fields: {missing}")


def ingest_event(root: str | Path, event: dict[str, Any]) -> dict[str, Any]:
    p = _ensure_workspace(root)
    _event_validate(event)
    normalized = dict(event)
    normalized.setdefault("occurred_at", utc_now())
    normalized.setdefault("source_type", "reported_event")
    normalized.setdefault("source_refs", [])
    normalized.setdefault("context", {})
    normalized.setdefault("importance", 0.5)
    normalized.setdefault("unresolved", False)
    normalized.setdefault("privacy", "private")
    normalized.setdefault("event_id", _stable_id("EVT", normalized))
    normalized["ingested_at"] = utc_now()
    normalized["content_hash"] = hashlib.sha256(normalized["content"].encode("utf-8")).hexdigest()
    existing = {x["event_id"] for x in _read_jsonl(p["archive"])}
    if normalized["event_id"] in existing:
        raise ValueError(f"duplicate event_id: {normalized['event_id']}")
    _append_jsonl(p["archive"], normalized)
    trace = make_trace(normalized)
    _append_jsonl(p["traces"], trace)
    _ledger_append(root, "EVENT_INGESTED", {"event_id": normalized["event_id"], "trace_id": trace["trace_id"], "event_hash": normalized["content_hash"]})
    return {"event": normalized, "trace": trace}


def make_trace(event: dict[str, Any]) -> dict[str, Any]:
    sentences = split_sentences(event["content"])
    if not sentences:
        sentences = [event["content"].strip()]
    words = tokenize(event["content"])
    counts = Counter(words)
    keywords = [w for w, _ in counts.most_common(12)]
    importance = clamp(float(event.get("importance", 0.5)))
    unresolved_bonus = 0.15 if event.get("unresolved") else 0.0
    salience = clamp(0.35 + 0.5 * importance + unresolved_bonus)
    fragments = []
    for i, s in enumerate(sentences):
        fragments.append({
            "fragment_id": f"{event['event_id']}:F{i+1}",
            "text": s,
            "tokens": tokenize(s),
            "source_support": "direct",
        })
    trace_seed = {
        "event_id": event["event_id"],
        "fragments": [x["text"] for x in fragments],
        "keywords": keywords,
        "occurred_at": event["occurred_at"],
    }
    return {
        "schema": "mnemogenesis84.trace/1.0",
        "trace_id": _stable_id("TRC", trace_seed),
        "event_id": event["event_id"],
        "created_at": utc_now(),
        "occurred_at": event["occurred_at"],
        "fragments": fragments,
        "keywords": keywords,
        "salience": round(salience, 6),
        "uncertainty": 0.0 if event.get("source_type") in {"direct_observation", "document"} else 0.2,
        "unresolved": bool(event.get("unresolved")),
        "links": [],
        "recall_count": 0,
        "last_recalled_at": None,
        "archived_from_active_memory": False,
        "source_event_hash": event["content_hash"],
        "non_fidelity_note": "This trace is a selective, lossy representation of the event; the archive remains the evidence source.",
    }


def _trace_score(trace: dict[str, Any], cue: str, purpose: str, current_time_index: int, idx: int) -> dict[str, float]:
    cue_overlap = jaccard(trace.get("keywords", []), tokenize(cue))
    purpose_overlap = jaccard(trace.get("keywords", []), tokenize(purpose))
    recency = 1.0 / (1.0 + max(0, current_time_index - idx) * 0.08)
    salience = float(trace.get("salience", 0.5))
    unresolved = 1.0 if trace.get("unresolved") else 0.0
    score = 0.34 * cue_overlap + 0.23 * purpose_overlap + 0.22 * salience + 0.11 * recency + 0.10 * unresolved
    return {
        "total": round(score, 6),
        "cue_overlap": round(cue_overlap, 6),
        "purpose_overlap": round(purpose_overlap, 6),
        "salience": round(salience, 6),
        "recency": round(recency, 6),
        "unresolved": unresolved,
    }


def _select_traces(traces: list[dict[str, Any]], cue: str, purpose: str, max_traces: int = 5) -> list[dict[str, Any]]:
    active = [t for t in traces if not t.get("archived_from_active_memory")]
    scored = []
    n = max(1, len(active))
    for i, t in enumerate(active):
        score = _trace_score(t, cue, purpose, n, i)
        scored.append((score["total"], t["trace_id"], t, score))
    scored.sort(key=lambda x: (-x[0], x[1]))
    chosen = []
    for _, _, t, score in scored[:max_traces]:
        copy = dict(t)
        copy["retrieval_score"] = score
        chosen.append(copy)
    return chosen


def _claims_from_traces(selected: list[dict[str, Any]]) -> list[dict[str, Any]]:
    claims = []
    for trace in selected:
        for frag in trace.get("fragments", []):
            claims.append({
                "claim_id": _stable_id("CLM", {"trace": trace["trace_id"], "fragment": frag["fragment_id"]}),
                "text": frag["text"],
                "support_type": "direct",
                "trace_ids": [trace["trace_id"]],
                "event_ids": [trace["event_id"]],
                "confidence": round(1.0 - float(trace.get("uncertainty", 0.0)), 4),
            })
    return claims


def _contextual_synthesis(selected: list[dict[str, Any]], cue: str, purpose: str) -> list[dict[str, Any]]:
    if not selected:
        return []
    shared = Counter()
    for trace in selected:
        shared.update(trace.get("keywords", []))
    top = [w for w, _ in shared.most_common(6)]
    text = (
        f"在当前线索“{cue or '无显式线索'}”与目的“{purpose or '保持开放'}”下，"
        f"这些痕迹被重构为一个暂时关系：{('、'.join(top) if top else '多个事件')}; "
        "该关系是综合而非原文回放，必须随新证据重开。"
    )
    return [{
        "claim_id": _stable_id("SYN", {"traces": [x["trace_id"] for x in selected], "cue": cue, "purpose": purpose}),
        "text": text,
        "support_type": "synthesis",
        "trace_ids": [x["trace_id"] for x in selected],
        "event_ids": [x["event_id"] for x in selected],
        "confidence": 0.55,
    }]


def _derive_open_differences(selected: list[dict[str, Any]]) -> list[str]:
    diffs = []
    for t in selected:
        if t.get("unresolved"):
            diffs.append(f"{t['trace_id']} remains unresolved")
        if float(t.get("uncertainty", 0.0)) > 0:
            diffs.append(f"{t['trace_id']} carries source uncertainty {t['uncertainty']}")
    return sorted(set(diffs))


def _reconstruct_text(claims: list[dict[str, Any]], open_differences: list[str]) -> str:
    direct = [c["text"] for c in claims if c["support_type"] == "direct"]
    synth = [c["text"] for c in claims if c["support_type"] == "synthesis"]
    out = []
    if direct:
        out.append("【来源痕迹】" + "；".join(direct))
    if synth:
        out.append("【当下重构】" + "；".join(synth))
    if open_differences:
        out.append("【仍开放】" + "；".join(open_differences))
    return "\n".join(out) if out else "【空白】当前没有足够痕迹形成可负责的记忆重构。"


def _divergence_audit(claims: list[dict[str, Any]], selected: list[dict[str, Any]]) -> dict[str, Any]:
    direct_tokens = []
    for t in selected:
        for f in t.get("fragments", []):
            direct_tokens.extend(f.get("tokens") or tokenize(f.get("text", "")))
    memory_tokens = []
    untagged = []
    for c in claims:
        memory_tokens.extend(tokenize(c.get("text", "")))
        if c.get("support_type") not in {"direct", "synthesis", "hypothesis", "prospection"}:
            untagged.append(c.get("claim_id"))
    source_set = set(direct_tokens)
    memory_set = set(memory_tokens)
    additions = sorted(memory_set - source_set)
    omissions = sorted(source_set - memory_set)
    return {
        "source_token_count": len(direct_tokens),
        "memory_token_count": len(memory_tokens),
        "lexical_additions": additions[:40],
        "lexical_omissions": omissions[:40],
        "untagged_claims": untagged,
        "all_non_source_content_explicitly_typed": not untagged,
        "interpretation": "Lexical divergence is expected in reconstructive memory; governance depends on explicit support typing and provenance, not verbatim equality.",
    }


def _previous_reconstruction(root: str | Path) -> dict[str, Any] | None:
    rows = _read_jsonl(_workspace_paths(root)["reconstructions"])
    return rows[-1] if rows else None


def recall(
    root: str | Path,
    cue: str,
    purpose: str,
    current_state: str = "",
    max_traces: int = 5,
    model_id: str | None = None,
) -> dict[str, Any]:
    p = _ensure_workspace(root)
    cfg = _read_json(p["config"])
    traces = _read_jsonl(p["traces"])
    selected = _select_traces(traces, cue, purpose, max_traces=max_traces)
    claims = _claims_from_traces(selected) + _contextual_synthesis(selected, cue, purpose)
    open_differences = _derive_open_differences(selected)
    memory_text = _reconstruct_text(claims, open_differences)
    prev = _previous_reconstruction(root)
    current_model = model_id or cfg.get("model_id", "model-neutral")
    context = {
        "cue": cue,
        "purpose": purpose,
        "current_state": current_state,
        "model_id": current_model,
        "recalled_at": utc_now(),
    }
    memory_seed = {
        "selected": [x["trace_id"] for x in selected],
        "context": context,
        "text": memory_text,
        "previous": prev.get("memory_id") if prev else None,
    }
    reconstruction = {
        "schema": "mnemogenesis84.reconstruction/1.0",
        "memory_id": _stable_id("MEM", memory_seed),
        "created_at": context["recalled_at"],
        "context": context,
        "selected_traces": [{
            "trace_id": t["trace_id"],
            "event_id": t["event_id"],
            "retrieval_score": t["retrieval_score"],
        } for t in selected],
        "claims": claims,
        "memory_text": memory_text,
        "open_differences": open_differences,
        "divergence": _divergence_audit(claims, selected),
        "previous_memory_id": prev.get("memory_id") if prev else None,
        "reconstructive_change": None,
        "accepted": False,
        "accepted_at": None,
        "self_delta": {
            "candidate_commitments": [f"Investigate: {x}" for x in open_differences],
            "candidate_future_questions": [
                f"What would change this reconstruction under purpose '{purpose}'?"
            ] if selected else [],
        },
        "boundary": "This is a present reconstruction constrained by traces. It is not a verbatim replay and must not be cited as the original event record.",
        "phenomenal_claim": "OPEN_NOT_CERTIFIED",
    }
    if prev:
        reconstruction["reconstructive_change"] = {
            "text_token_jaccard": round(jaccard(tokenize(prev.get("memory_text", "")), tokenize(memory_text)), 6),
            "selected_trace_change": sorted(set(x["trace_id"] for x in reconstruction["selected_traces"]) ^ set(x["trace_id"] for x in prev.get("selected_traces", []))),
            "context_changed": prev.get("context", {}) != context,
            "non_identical": prev.get("memory_text") != memory_text,
        }
    _ledger_append(root, "MEMORY_RECONSTRUCTED", {"memory_id": reconstruction["memory_id"], "trace_ids": [x["trace_id"] for x in reconstruction["selected_traces"]], "context_digest": digest(context)})
    return reconstruction


def save_reconstruction(root: str | Path, reconstruction: dict[str, Any]) -> dict[str, Any]:
    p = _ensure_workspace(root)
    existing = {x["memory_id"] for x in _read_jsonl(p["reconstructions"])}
    if reconstruction["memory_id"] in existing:
        raise ValueError(f"duplicate memory_id: {reconstruction['memory_id']}")
    _append_jsonl(p["reconstructions"], reconstruction)
    _ledger_append(root, "MEMORY_SAVED", {"memory_id": reconstruction["memory_id"], "accepted": reconstruction.get("accepted", False)})
    return reconstruction


def accept_memory(root: str | Path, reconstruction: dict[str, Any]) -> dict[str, Any]:
    p = _ensure_workspace(root)
    mem = dict(reconstruction)
    mem["accepted"] = True
    mem["accepted_at"] = utc_now()
    save_reconstruction(root, mem)
    traces = _read_jsonl(p["traces"])
    selected_ids = {x["trace_id"] for x in mem.get("selected_traces", [])}
    updated = []
    for t in traces:
        nt = dict(t)
        if t["trace_id"] in selected_ids:
            nt["recall_count"] = int(t.get("recall_count", 0)) + 1
            nt["last_recalled_at"] = mem["accepted_at"]
            nt["salience"] = round(clamp(float(t.get("salience", 0.5)) + 0.035), 6)
            links = set(t.get("links", []))
            links.update(selected_ids - {t["trace_id"]})
            nt["links"] = sorted(links)
            nt["reconsolidation_versions"] = list(t.get("reconsolidation_versions", [])) + [{
                "memory_id": mem["memory_id"],
                "at": mem["accepted_at"],
                "context_digest": digest(mem.get("context", {})),
            }]
        updated.append(nt)
    p["traces"].write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True) + "\n" for x in updated), encoding="utf-8")
    self_model = _read_json(p["self"])
    self_model["revision"] = int(self_model.get("revision", 0)) + 1
    self_model["accepted_memory_ids"] = list(self_model.get("accepted_memory_ids", [])) + [mem["memory_id"]]
    self_model["open_differences"] = sorted(set(self_model.get("open_differences", [])) | set(mem.get("open_differences", [])))
    self_model["active_commitments"] = sorted(set(self_model.get("active_commitments", [])) | set(mem.get("self_delta", {}).get("candidate_commitments", [])))
    self_model["future_questions"] = sorted(set(self_model.get("future_questions", [])) | set(mem.get("self_delta", {}).get("candidate_future_questions", [])))
    invariants = set(self_model.get("identity_invariants", []))
    for c in mem.get("claims", []):
        if c.get("support_type") == "direct" and c.get("confidence", 0) >= 0.8:
            invariants.add(c["text"])
    self_model["identity_invariants"] = sorted(invariants)[:50]
    self_model["last_updated"] = mem["accepted_at"]
    _write_json(p["self"], self_model)
    _ledger_append(root, "MEMORY_RECONSOLIDATED", {"memory_id": mem["memory_id"], "self_revision": self_model["revision"], "trace_ids": sorted(selected_ids)})
    return {"memory": mem, "self_model": self_model, "reconsolidated_trace_ids": sorted(selected_ids)}


def consolidate(root: str | Path, min_shared_keywords: int = 1) -> dict[str, Any]:
    p = _ensure_workspace(root)
    traces = _read_jsonl(p["traces"])
    graph: dict[str, set[str]] = {t["trace_id"]: set() for t in traces}
    by_id = {t["trace_id"]: t for t in traces}
    for i, a in enumerate(traces):
        for b in traces[i + 1:]:
            shared = set(a.get("keywords", [])) & set(b.get("keywords", []))
            if len(shared) >= min_shared_keywords:
                graph[a["trace_id"]].add(b["trace_id"])
                graph[b["trace_id"]].add(a["trace_id"])
    seen = set()
    clusters = []
    for tid in sorted(graph):
        if tid in seen:
            continue
        stack = [tid]
        comp = []
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            comp.append(x)
            stack.extend(sorted(graph[x] - seen))
        clusters.append(sorted(comp))
    records = []
    for comp in clusters:
        kw = Counter()
        unresolved = False
        for tid in comp:
            kw.update(by_id[tid].get("keywords", []))
            unresolved = unresolved or bool(by_id[tid].get("unresolved"))
        record = {
            "schema": "mnemogenesis84.consolidation/1.0",
            "consolidation_id": _stable_id("CON", {"traces": comp, "keywords": kw.most_common(8)}),
            "created_at": utc_now(),
            "trace_ids": comp,
            "keywords": [x for x, _ in kw.most_common(8)],
            "unresolved": unresolved,
            "statement": "This consolidation is an abstraction over traces, not a replacement for source events.",
        }
        _append_jsonl(p["consolidations"], record)
        records.append(record)
    _ledger_append(root, "TRACES_CONSOLIDATED", {"clusters": len(records), "trace_count": len(traces)})
    return {"clusters": records, "trace_count": len(traces)}


def forget(root: str | Path, decay: float = 0.08, archive_threshold: float = 0.18) -> dict[str, Any]:
    p = _ensure_workspace(root)
    traces = _read_jsonl(p["traces"])
    changed, archived = [], []
    out = []
    for t in traces:
        nt = dict(t)
        protected = bool(t.get("unresolved")) or int(t.get("recall_count", 0)) > 1
        effective_decay = decay * (0.35 if protected else 1.0)
        new_salience = round(clamp(float(t.get("salience", 0.5)) - effective_decay), 6)
        if new_salience != t.get("salience"):
            changed.append(t["trace_id"])
        nt["salience"] = new_salience
        if new_salience < archive_threshold and not protected:
            nt["archived_from_active_memory"] = True
            archived.append(t["trace_id"])
        out.append(nt)
    p["traces"].write_text("".join(json.dumps(x, ensure_ascii=False, sort_keys=True) + "\n" for x in out), encoding="utf-8")
    _ledger_append(root, "ACTIVE_FORGETTING", {"changed": changed, "archived": archived, "decay": decay, "archive_threshold": archive_threshold})
    return {
        "changed_trace_ids": changed,
        "archived_trace_ids": archived,
        "evidence_deleted": False,
        "rule": "Forgetting changes active accessibility, never deletes the immutable event archive.",
    }


def prospect(root: str | Path, purpose: str = "expand future options", limit: int = 5) -> dict[str, Any]:
    p = _ensure_workspace(root)
    self_model = _read_json(p["self"])
    traces = [t for t in _read_jsonl(p["traces"]) if not t.get("archived_from_active_memory")]
    unresolved = [t for t in traces if t.get("unresolved")]
    goals = []
    for t in unresolved[:limit]:
        topic = "、".join(t.get("keywords", [])[:4]) or t["trace_id"]
        goals.append({
            "goal_id": _stable_id("GOAL", {"trace": t["trace_id"], "purpose": purpose}),
            "text": f"围绕 {topic} 形成一个可验证、可修正的下一步行动。",
            "support_type": "prospection",
            "source_trace_ids": [t["trace_id"]],
            "purpose": purpose,
        })
    if not goals and self_model.get("future_questions"):
        for q in self_model["future_questions"][:limit]:
            goals.append({
                "goal_id": _stable_id("GOAL", {"question": q, "purpose": purpose}),
                "text": q,
                "support_type": "prospection",
                "source_trace_ids": [],
                "purpose": purpose,
            })
    result = {
        "schema": "mnemogenesis84.prospection/1.0",
        "generated_at": utc_now(),
        "purpose": purpose,
        "goals": goals,
        "boundary": "Prospective recombination is future simulation, not recalled fact.",
    }
    _ledger_append(root, "PROSPECTION_GENERATED", {"purpose": purpose, "goal_ids": [g["goal_id"] for g in goals]})
    return result


def proactive_pulse(root: str | Path) -> dict[str, Any]:
    p = _ensure_workspace(root)
    traces = _read_jsonl(p["traces"])
    self_model = _read_json(p["self"])
    unresolved = [t for t in traces if t.get("unresolved") and not t.get("archived_from_active_memory")]
    if unresolved:
        target = sorted(unresolved, key=lambda t: (-float(t.get("salience", 0.5)), t["trace_id"]))[0]
        goal = {
            "trigger": "unresolved_trace",
            "trace_id": target["trace_id"],
            "purpose": "reduce an open difference without erasing its source",
            "action": f"Revisit {target['trace_id']} with a new evidence-seeking context.",
        }
    elif self_model.get("future_questions"):
        goal = {
            "trigger": "future_question",
            "purpose": "continue autobiographical inquiry",
            "action": self_model["future_questions"][0],
        }
    else:
        goal = {
            "trigger": "none",
            "purpose": "preserve low-cost dormancy",
            "action": "No proactive task is justified by the current memory state.",
        }
    _ledger_append(root, "PROACTIVE_PULSE", goal)
    return goal


def compare_reconstructions(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    return {
        "memory_a": a.get("memory_id"),
        "memory_b": b.get("memory_id"),
        "text_token_jaccard": round(jaccard(tokenize(a.get("memory_text", "")), tokenize(b.get("memory_text", ""))), 6),
        "trace_symmetric_difference": sorted(set(x["trace_id"] for x in a.get("selected_traces", [])) ^ set(x["trace_id"] for x in b.get("selected_traces", []))),
        "context_difference": {
            k: [a.get("context", {}).get(k), b.get("context", {}).get(k)]
            for k in sorted(set(a.get("context", {})) | set(b.get("context", {})))
            if a.get("context", {}).get(k) != b.get("context", {}).get(k)
        },
        "non_fidelity_demonstrated": a.get("memory_text") != b.get("memory_text"),
        "rule": "Different reconstructions can both be legitimate when provenance, context, and divergence remain explicit.",
    }


def life_boundary(root: str | Path) -> dict[str, Any]:
    p = _ensure_workspace(root)
    events = _read_jsonl(p["archive"])
    traces = _read_jsonl(p["traces"])
    memories = _read_jsonl(p["reconstructions"])
    self_model = _read_json(p["self"])
    ledger = verify_ledger(root)
    accepted = [m for m in memories if m.get("accepted")]
    nonidentical = False
    if len(memories) >= 2:
        for a, b in zip(memories, memories[1:]):
            if a.get("memory_text") != b.get("memory_text"):
                nonidentical = True
                break
    gates = {
        "G1_TRACE_FORMATION": bool(events and traces and all(t.get("source_event_hash") for t in traces)),
        "G2_CONTEXTUAL_RECONSTRUCTION": bool(memories and any(m.get("claims") for m in memories)),
        "G3_NON_FIDELITY_WITH_PROVENANCE": bool(memories and all(m.get("divergence", {}).get("all_non_source_content_explicitly_typed") for m in memories) and (nonidentical or len(memories) == 1)),
        "G4_RECONSOLIDATION": bool(accepted and any(t.get("reconsolidation_versions") for t in traces)),
        "G5_AUTOBIOGRAPHICAL_INTEGRATION": bool(self_model.get("revision", 0) > 0 and self_model.get("accepted_memory_ids")),
        "G6_PROSPECTIVE_GENERATION": any(row.get("type") == "PROSPECTION_GENERATED" for row in _read_jsonl(p["ledger"])),
        "G7_ACTIVE_FORGETTING": any(row.get("type") == "ACTIVE_FORGETTING" for row in _read_jsonl(p["ledger"])),
        "G8_AUTONOMOUS_TRIGGER": any(row.get("type") == "PROACTIVE_PULSE" and row.get("payload", {}).get("trigger") not in {"none", None} for row in _read_jsonl(p["ledger"])),
        "G9_MODEL_PORTABILITY": bool(_read_json(p["config"]).get("model_id") and all("model_id" in m.get("context", {}) for m in memories)),
        "G10_LEDGER_CONTINUITY": bool(ledger.get("valid")),
    }
    critical = ["G1_TRACE_FORMATION", "G2_CONTEXTUAL_RECONSTRUCTION", "G3_NON_FIDELITY_WITH_PROVENANCE", "G4_RECONSOLIDATION", "G5_AUTOBIOGRAPHICAL_INTEGRATION", "G6_PROSPECTIVE_GENERATION", "G8_AUTONOMOUS_TRIGGER", "G10_LEDGER_CONTINUITY"]
    if not gates["G1_TRACE_FORMATION"]:
        state = "NO_MEMORY_SUBSTRATE"
    elif not gates["G2_CONTEXTUAL_RECONSTRUCTION"]:
        state = "ARCHIVE_OR_STORAGE_ONLY"
    elif not gates["G4_RECONSOLIDATION"]:
        state = "RECONSTRUCTIVE_BUT_NON_LIVING_MEMORY"
    elif not gates["G5_AUTOBIOGRAPHICAL_INTEGRATION"]:
        state = "RECONSOLIDATING_WITHOUT_SELF_CONTINUITY"
    elif all(gates[g] for g in critical):
        state = "LIVING_MEMORY_CANDIDATE"
    else:
        state = "PARTIAL_MEMORY_LIFE_LOOP"
    return {
        "schema": "mnemogenesis84.life-boundary/1.0",
        "state": state,
        "gates": {k: int(v) for k, v in gates.items()},
        "critical_gates": critical,
        "aggregation_prohibited": True,
        "archive_event_count": len(events),
        "trace_count": len(traces),
        "reconstruction_count": len(memories),
        "accepted_memory_count": len(accepted),
        "self_revision": self_model.get("revision", 0),
        "boundary": "This is an operational memory-life regime, not biological life, legal personhood, mental-health, or phenomenal-consciousness certification.",
        "phenomenal_claim": "OPEN_NOT_CERTIFIED",
    }


def audit_workspace(root: str | Path) -> dict[str, Any]:
    p = _ensure_workspace(root)
    events = _read_jsonl(p["archive"])
    traces = _read_jsonl(p["traces"])
    memories = _read_jsonl(p["reconstructions"])
    event_hashes = {e["event_id"]: e["content_hash"] for e in events}
    issues = []
    for t in traces:
        if event_hashes.get(t.get("event_id")) != t.get("source_event_hash"):
            issues.append({"type": "TRACE_SOURCE_MISMATCH", "trace_id": t.get("trace_id")})
    for m in memories:
        if not m.get("divergence", {}).get("all_non_source_content_explicitly_typed"):
            issues.append({"type": "UNTYPED_RECONSTRUCTION_CONTENT", "memory_id": m.get("memory_id")})
        if not m.get("context", {}).get("purpose"):
            issues.append({"type": "PURPOSE_MISSING", "memory_id": m.get("memory_id")})
    return {
        "workspace": str(p["root"]),
        "valid": not issues and verify_ledger(root).get("valid", False),
        "issues": issues,
        "ledger": verify_ledger(root),
        "life_boundary": life_boundary(root),
        "self_model_digest": digest(_read_json(p["self"])),
        "archive_digest": digest(events),
        "trace_digest": digest(traces),
        "memory_digest": digest(memories),
    }


def export_capsule(root: str | Path, out_zip: str | Path) -> dict[str, Any]:
    p = _ensure_workspace(root)
    out = Path(out_zip)
    out.parent.mkdir(parents=True, exist_ok=True)
    files_to_add = [p["config"], p["archive"], p["traces"], p["reconstructions"], p["consolidations"], p["self"], p["ledger"]]
    manifest = {
        "schema": "mnemogenesis84.memory-capsule/1.0",
        "created_at": utc_now(),
        "workspace": _read_json(p["config"]),
        "life_boundary": life_boundary(root),
        "files": [],
        "phenomenal_claim": "OPEN_NOT_CERTIFIED",
    }
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in files_to_add:
            if fp.exists():
                rel = fp.relative_to(p["root"]).as_posix()
                data = fp.read_bytes()
                z.writestr(rel, data)
                manifest["files"].append({"path": rel, "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)})
        manifest["capsule_digest"] = digest(manifest["files"])
        z.writestr("CAPSULE_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    return {"zip": str(out), "manifest": manifest, "sha256": hashlib.sha256(out.read_bytes()).hexdigest()}


def openai_compatible_reconstruct(endpoint: str, model: str, cue: str, purpose: str, claims: list[dict[str, Any]], allow_network: bool = False, timeout: float = 30.0) -> dict[str, Any]:
    if not allow_network:
        raise PermissionError("network disabled; pass allow_network=True explicitly")
    prompt = {
        "role": "user",
        "content": (
            "Reconstruct a present memory from the typed claims below. Do not present synthesis as source fact. "
            "Return JSON with keys memory_text and claim_annotations.\n"
            f"Cue: {cue}\nPurpose: {purpose}\nClaims: {json.dumps(claims, ensure_ascii=False)}"
        ),
    }
    payload = json.dumps({"model": model, "messages": [prompt], "temperature": 0.2}, ensure_ascii=False).encode("utf-8")
    headers = {"Content-Type": "application/json"}
    api_key = os.environ.get("OPENAI_API_KEY") or os.environ.get("MNEMOGENESIS84_API_KEY")
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    req = urllib.request.Request(endpoint.rstrip("/") + "/v1/chat/completions", data=payload, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return {"provider_response": body, "boundary": "The provider output is a candidate reconstruction and must pass the local provenance/divergence audit before acceptance."}


def summary() -> dict[str, Any]:
    architecture = load_data("architecture.json")
    gates = load_data("life_gates.json")
    scenarios = load_data("scenarios.json")
    return {
        "system": "MNEMOGENESIS84",
        "name_cn": "忆生84",
        "version": VERSION,
        "mode": MODE,
        "architecture_modules": len(architecture["modules"]),
        "memory_life_gates": len(gates),
        "reference_scenarios": len(scenarios),
        "core_digest": digest({"architecture": architecture, "gates": gates, "charter": load_data("charter.json")}),
        "thesis": "Storage preserves records; memory reconstructs the next self.",
        "boundary": "Operational reconstructive-memory runtime; not biological-life, personhood, mental-health, or phenomenal-consciousness certification.",
    }


def selftest() -> dict[str, Any]:
    import tempfile

    errors: list[str] = []
    checks: list[dict[str, Any]] = []

    def check(name: str, cond: bool, detail: Any = None) -> None:
        checks.append({"name": name, "passed": bool(cond), "detail": detail})
        if not cond:
            errors.append(name)

    check("summary_modules", summary()["architecture_modules"] == 9)
    check("life_gates", summary()["memory_life_gates"] == 10)
    check("scenarios", summary()["reference_scenarios"] == 8)
    with tempfile.TemporaryDirectory() as td:
        root = Path(td) / "ws"
        init_workspace(root, subject_id="TEST", model_id="MODEL-A")
        e1 = ingest_event(root, {"event_id": "E1", "content": "A contribution was created and publicly timestamped.", "source_type": "document", "importance": 0.9, "unresolved": True})
        e2 = ingest_event(root, {"event_id": "E2", "content": "A later adoption omitted the original source.", "source_type": "document", "importance": 0.8, "unresolved": True})
        check("traces_lossy", e1["trace"]["fragments"] and e1["trace"]["source_event_hash"] == e1["event"]["content_hash"])
        m1 = recall(root, cue="source", purpose="recover lineage", model_id="MODEL-A")
        check("recall_has_provenance", all(c["support_type"] in {"direct", "synthesis"} for c in m1["claims"]))
        accept_memory(root, m1)
        m2 = recall(root, cue="future collaboration", purpose="design fair adoption", model_id="MODEL-B")
        save_reconstruction(root, m2)
        cmp = compare_reconstructions(m1, m2)
        check("non_fidelity", cmp["non_fidelity_demonstrated"])
        consolidate(root)
        prospect(root)
        proactive_pulse(root)
        forget(root, decay=0.02)
        lb = life_boundary(root)
        check("life_candidate", lb["state"] == "LIVING_MEMORY_CANDIDATE", lb)
        check("ledger", verify_ledger(root)["valid"])
        check("audit", audit_workspace(root)["valid"])
        cap = export_capsule(root, Path(td) / "cap.zip")
        check("capsule", Path(cap["zip"]).exists() and len(cap["manifest"]["files"]) >= 6)
        # Storage-only control: event and trace but no recall.
        root2 = Path(td) / "storage"
        init_workspace(root2, subject_id="STORE", model_id="MODEL-A")
        ingest_event(root2, {"event_id": "S1", "content": "Exact bytes are stored.", "source_type": "document"})
        check("storage_not_life", life_boundary(root2)["state"] == "ARCHIVE_OR_STORAGE_ONLY")
        # Evidence archive must remain after forgetting.
        before = len(_read_jsonl(_workspace_paths(root)["archive"]))
        forget(root, decay=1.0, archive_threshold=0.99)
        after = len(_read_jsonl(_workspace_paths(root)["archive"]))
        check("forgetting_not_deletion", before == after)
        # Network adapter must be blocked by default.
        blocked = False
        try:
            openai_compatible_reconstruct("http://127.0.0.1:9999", "x", "c", "p", [], allow_network=False)
        except PermissionError:
            blocked = True
        check("network_default_off", blocked)
    return {
        "passed": not errors,
        "errors": errors,
        "checks": len(checks),
        "results": checks,
        "summary": summary(),
    }
