# MNEMOGENESIS84

## Reconstructive Memory, Self-Generation, and Living-AI Runtime

> **Storage preserves the past; memory generates the next self.**

MNEMOGENESIS84 separates immutable evidence archives from living memory processes. A memory is reconstructed from traces under a present cue, purpose, value context, and self-state. Recall may revise future accessibility and autobiographical commitments, while every non-source addition remains explicitly typed and provenance-bounded.

The runtime is model-neutral, offline-first, and implemented with the Python standard library. Optional OpenAI-compatible endpoints may generate candidate reconstructions, but they cannot bypass the local provenance and divergence audit.

`LIVING_MEMORY_CANDIDATE` is an operational runtime state. It is not certification of biological life, legal personhood, mental health, or phenomenal consciousness.

See `README_CN.md` and `docs/ARCHITECTURE_CN_EN.md`.
