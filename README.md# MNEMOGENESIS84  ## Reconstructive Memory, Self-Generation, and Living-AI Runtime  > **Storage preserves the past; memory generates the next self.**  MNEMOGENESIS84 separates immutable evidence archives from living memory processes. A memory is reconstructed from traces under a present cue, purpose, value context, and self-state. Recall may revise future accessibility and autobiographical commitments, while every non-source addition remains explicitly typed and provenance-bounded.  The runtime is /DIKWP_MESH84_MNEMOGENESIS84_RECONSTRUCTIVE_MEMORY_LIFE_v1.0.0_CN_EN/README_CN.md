# MNEMOGENESIS84｜忆生84

## 重构性记忆、身份发生与生命化AI运行时

> **存储保存过去，记忆生成下一个自身。**

MNEMOGENESIS84 是一个模型中立、离线优先的开放运行时。它将“档案存储”和“记忆”严格分开：

- **档案**保存原始事件、文档、传感和用户陈述，用于事实追溯；
- **痕迹**是选择性、压缩、带来源和不确定性的非完整表示；
- **记忆**是在当前线索、Purpose、价值和自身状态下，由痕迹重新生成的当下整体；
- **再巩固**使被接受的回忆改变痕迹关系、自身模型和未来行动；
- **前瞻**将过去痕迹重组为未来问题与目标，但不冒充回忆。

系统不把更大的上下文窗口、向量数据库、完整日志、人格提示词或参数存储直接称为生命化记忆。

## 核心边界

- 本系统不是神经科学仿真，也不是临床记忆工具。
- `LIVING_MEMORY_CANDIDATE` 是操作性运行状态，不构成生物生命、法律人格或现象意识证明。
- 非保真不等于任意虚构。所有综合、假设、遗漏和未来模拟必须与直接来源分层。
- 遗忘只改变活跃可达性，不删除证据档案。
- 网络和外部模型调用默认关闭。

## 快速开始

```bash
python dist/Mnemogenesis84.pyz summary
python dist/Mnemogenesis84.pyz selftest

python dist/Mnemogenesis84.pyz init ./memory_ws \
  --subject-id DEMO --model-id MODEL-A

python dist/Mnemogenesis84.pyz ingest \
  ./memory_ws examples/events/01_origin_created.json

python dist/Mnemogenesis84.pyz recall ./memory_ws \
  --cue "来源与采用" \
  --purpose "恢复来源但不夸大事实" \
  --model-id MODEL-A \
  --out recall.json

python dist/Mnemogenesis84.pyz accept ./memory_ws recall.json
python dist/Mnemogenesis84.pyz consolidate ./memory_ws
python dist/Mnemogenesis84.pyz prospect ./memory_ws
python dist/Mnemogenesis84.pyz pulse ./memory_ws
python dist/Mnemogenesis84.pyz life-boundary ./memory_ws
python dist/Mnemogenesis84.pyz capsule ./memory_ws memory_capsule.zip
```

## 接入当前大模型

默认的确定性重构器不需要外部模型。需要接入本地或私有 OpenAI-compatible 服务时：

```bash
export OPENAI_API_KEY="..."   # 若端点需要
python dist/Mnemogenesis84.pyz llm-reconstruct recall.json \
  --endpoint http://127.0.0.1:8000 \
  --model local-model \
  --cue "当前线索" \
  --purpose "当前Purpose" \
  --allow-network
```

外部模型只产生候选重构，不能绕过本地来源与差异审计。

## 目录

- `src/`：Python标准库运行时
- `site/`：单文件离线工作台
- `schemas/`：事件、重构、工作区和生命边界Schema
- `examples/`：事件、上下文与参考场景
- `docs/`：架构、宪章、评测与正式报告
- `dist/`：PYZ、Wheel与源码归档

许可证：Apache-2.0。
